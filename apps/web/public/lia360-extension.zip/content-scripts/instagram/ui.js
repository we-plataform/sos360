"use strict";(function(){"use strict";const c=window.LiaInstagramUtils;if(!c){console.error("[Lia 360 UI] Utils not loaded");return}const i="sos360-instagram-overlay",k="sos360-post-overlay",n="sos360-followers-overlay";function f(){if(document.getElementById(i)){document.getElementById(i).style.display="block";return}const e=c.getCurrentProfileUsername(),t=window.LiaInstagramState;t&&(t.currentProfileUsername=e);const o=document.createElement("div");o.id=i,o.innerHTML=`
      <div class="sos-header">
        <span class="sos-title">Import: @${e||"Instagram"}</span>
        <button id="sos-close" class="sos-close">&times;</button>
      </div>
      <div class="sos-content">
        <div class="sos-input-group">
          <label for="sos-keywords">Filtrar por Keywords (bio/nome):</label>
          <input type="text" id="sos-keywords" placeholder="Ex: Marketing, CEO, Empreendedor">
        </div>
        <div class="sos-input-group">
          <label for="sos-criteria">Crit\xE9rios de Qualifica\xE7\xE3o IA:</label>
          <input type="text" id="sos-criteria" placeholder="Ex: Profissionais de marketing digital">
        </div>
        <div class="sos-checkbox-group" style="display:flex; align-items:center; gap:8px; margin-top:4px;">
          <input type="checkbox" id="sos-ai-qualify" style="width:16px; height:16px; cursor:pointer;">
          <label for="sos-ai-qualify" style="cursor:pointer; font-size:12px; color:#d1d5db;">\u{1F916} Qualificar com IA durante scan</label>
        </div>
        <div class="sos-stats">
          <div class="stat-item">
            <span class="label">Escaneados</span>
            <span class="value" id="sos-scanned-count">0</span>
          </div>
          <div class="stat-item">
            <span class="label">Qualificados</span>
            <span class="value" id="sos-qualified-count">0</span>
          </div>
        </div>
        <div class="sos-dialog-actions">
          <button id="sos-open-followers" class="sos-btn sos-btn-secondary">
            \u{1F465} Abrir Seguidores
          </button>
          <button id="sos-open-following" class="sos-btn sos-btn-secondary">
            \u{1F464} Abrir Seguindo
          </button>
        </div>
        <div class="sos-actions">
          <button id="sos-scan-btn" class="sos-btn sos-btn-primary">
            \u{1F50D} Scanear Dialog
          </button>
          <button id="sos-import-btn" class="sos-btn sos-btn-action" disabled>
            <span class="icon">\u2601\uFE0F</span> <span id="sos-import-text">Importar 0 perfis...</span>
          </button>
        </div>
      </div>
      <style>
      #${i} {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 320px;
        background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
        color: #fff;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(225, 48, 108, 0.3);
        z-index: 2147483647;
        font-family: -apple-system, system-ui, sans-serif;
        border: 1px solid rgba(225, 48, 108, 0.3);
      }
      #${i} .sos-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        background: linear-gradient(90deg, #833ab4, #e1306c);
        border-radius: 12px 12px 0 0;
      }
      #${i} .sos-title { font-weight: 600; font-size: 14px; }
      #${i} .sos-close { background: none; border: none; color: white; font-size: 20px; cursor: pointer; opacity: 0.8; }
      #${i} .sos-close:hover { opacity: 1; }
      #${i} .sos-content { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
      #${i} .sos-input-group { display: flex; flex-direction: column; gap: 6px; }
      #${i} label { font-size: 12px; color: #d1d5db; }
      #${i} input {
        background: #1f2937;
        border: 1px solid #374151;
        border-radius: 6px;
        padding: 10px 12px;
        font-size: 13px;
        color: #fff;
        transition: border-color 0.2s;
      }
      #${i} input:focus {
        outline: none;
        border-color: #e1306c;
      }
      #${i} .sos-stats {
        display: flex;
        justify-content: space-around;
        background: rgba(0,0,0,0.3);
        padding: 12px;
        border-radius: 8px;
      }
      #${i} .stat-item { display: flex; flex-direction: column; align-items: center; }
      #${i} .stat-item .label { font-size: 10px; color: #9ca3af; text-transform: uppercase; }
      #${i} .stat-item .value { font-size: 20px; font-weight: bold; color: #fff; }
      #${i} .sos-dialog-actions { display: flex; gap: 8px; }
      #${i} .sos-actions { display: flex; flex-direction: column; gap: 8px; }
      #${i} .sos-btn {
        width: 100%;
        padding: 12px;
        border: none;
        border-radius: 8px;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 8px;
        transition: all 0.2s;
      }
      #${i} .sos-btn:hover:not(:disabled) { transform: translateY(-1px); }
      #${i} .sos-btn:disabled { opacity: 0.5; cursor: not-allowed; }
      #${i} .sos-btn-primary {
        background: linear-gradient(90deg, #833ab4, #e1306c);
        color: white;
      }
      #${i} .sos-btn-secondary {
        background: #374151;
        color: white;
        flex: 1;
      }
      #${i} .sos-btn-secondary:hover:not(:disabled) { background: #4b5563; }
      #${i} .sos-btn-action {
        background: linear-gradient(90deg, #e1306c, #f77737);
        color: white;
      }
      #${i} .sos-btn-stop {
        background: #ef4444;
        color: white;
      }
      </style>
    `,document.body.appendChild(o),document.getElementById("sos-close").addEventListener("click",()=>{document.getElementById(i).style.display="none",window.LiaInstagramFollowers&&window.LiaInstagramFollowers.stopFollowersScanning()}),document.getElementById("sos-keywords").addEventListener("input",s=>{window.LiaInstagramState&&g(s.target.value)}),document.getElementById("sos-criteria").addEventListener("input",s=>{const r=window.LiaInstagramState;r&&(r.criteria=s.target.value.trim())}),document.getElementById("sos-ai-qualify").addEventListener("change",s=>{const r=window.LiaInstagramState;r&&(r.useAIQualification=s.target.checked,r.useAIQualification||(r.pendingAIBatch=[]))}),document.getElementById("sos-open-followers").addEventListener("click",()=>{window.LiaInstagramFollowers&&window.LiaInstagramFollowers.openFollowersDialog()}),document.getElementById("sos-open-following").addEventListener("click",()=>{window.LiaInstagramFollowers&&window.LiaInstagramFollowers.openFollowingDialog()}),document.getElementById("sos-scan-btn").addEventListener("click",w),document.getElementById("sos-import-btn").addEventListener("click",y)}function g(e){const t=window.LiaInstagramState;t&&(t.keywords=e.trim()?e.split(",").map(o=>o.trim()).filter(Boolean):[],b())}function b(){const e=window.LiaInstagramState;if(!(!e||e.keywords.length===0)){for(const[t,o]of e.qualifiedLeads){const s=`${o.fullName||""} ${o.bio||""}`.toLowerCase();c.matchesKeywords(s,e.keywords)||e.qualifiedLeads.delete(t)}p()}}function p(){const e=window.LiaInstagramState;if(!e)return;const t=document.getElementById("sos-scanned-count"),o=document.getElementById("sos-qualified-count"),s=document.getElementById("sos-import-btn"),r=document.getElementById("sos-import-text"),a=document.getElementById("sos-scan-btn");document.getElementById(i)&&(t&&(t.textContent=e.totalUsersFound),o&&(o.textContent=e.qualifiedLeads.size),s&&(s.disabled=e.qualifiedLeads.size===0,r.textContent=`Importar ${e.qualifiedLeads.size} perfis...`),a&&(e.isAutoScrolling?(a.textContent="\u23F9\uFE0F Parar Scan",a.className="sos-btn sos-btn-stop"):(a.textContent="\u{1F50D} Scanear Dialog",a.className="sos-btn sos-btn-primary")))}function w(){const e=window.LiaInstagramState;if(e){if(e.isAutoScrolling)window.LiaInstagramFollowers&&window.LiaInstagramFollowers.stopFollowersScanning();else{if(!document.querySelector('div[role="dialog"]')){alert("Por favor, abra o dialog de seguidores ou seguindo primeiro.");return}window.LiaInstagramFollowers&&window.LiaInstagramFollowers.startFollowersScanning()}p()}}async function y(){const e=window.LiaInstagramState;if(!e)return;const t=Array.from(e.qualifiedLeads.values());if(t.length===0)return;const o=document.getElementById("sos-import-btn"),s=document.getElementById("sos-import-text");if(!o||!s)return;const r=s.textContent;o.disabled=!0,s.textContent="Importando...";try{const a=await chrome.runtime.sendMessage({action:"importLeads",data:{source:"extension",platform:"instagram",sourceUrl:window.location.href,leads:t}});a?.success?(alert(`Sucesso! ${t.length} leads importados.`),e.qualifiedLeads.clear(),e.totalUsersFound=0,p()):alert("Falha na importa\xE7\xE3o: "+(a?.error||"Erro desconhecido"))}catch(a){console.error("[Lia 360 UI] Import exception:",a),alert("Erro: "+a.message)}finally{o.disabled=!1,s.textContent=r}}function x(){d();const e=window.LiaInstagramState,t=e&&e.dialogType==="followers"?"Followers":"Following",o=document.createElement("div");o.id=n,o.innerHTML=`
      <div class="sos-followers-header">
        <span class="sos-title">Import: ${t}</span>
        <div class="sos-header-actions">
          <button id="sos-minimize-followers-btn" title="Minimize">\u2212</button>
          <button id="sos-close-followers-btn" title="Close">\xD7</button>
        </div>
      </div>

      <div class="sos-followers-body" id="sos-followers-body">
        <div class="sos-field">
          <label>Audience:</label>
          <select id="sos-audience-select">
            <option value="">No audience filter</option>
          </select>
        </div>

        <div class="sos-field">
          <label>Filter by Keywords:</label>
          <input type="text" id="sos-followers-keywords" placeholder="Keywords between commas">
        </div>

        <div class="sos-field sos-inline">
          <label>Scroll until</label>
          <input type="number" id="sos-scroll-limit" value="${e?e.followersScrollLimit:300}" min="50" max="1000" step="50">
          <span>profiles</span>
        </div>

        <div class="sos-stats">
          <div class="stat-item">
            <span class="label">Scanned</span>
            <span class="value" id="sos-followers-scanned-count">0</span>
          </div>
          <div class="stat-item">
            <span class="label">Qualified</span>
            <span class="value" id="sos-followers-qualified-count">0</span>
          </div>
        </div>

        <button id="sos-start-scroll-btn" class="sos-btn-primary">
          \u27F3 Start Auto-Scroll
        </button>

        <button id="sos-followers-import-btn" class="sos-btn-secondary" disabled>
          \u2601 Import 0 profiles...
        </button>

        <div class="sos-warning">
          <strong>\u26A0 Attention:</strong> We recommend limiting your scrolling to 300
          profiles and/or scrolling over a longer period of time, to avoid triggering
          account suspension.
        </div>
      </div>

      <style>
      #${n} {
        position: fixed;
        bottom: 20px;
        right: 20px;
        width: 300px;
        background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
        border-radius: 12px;
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        box-shadow: 0 8px 32px rgba(0,0,0,0.4);
        border: 1px solid rgba(255,255,255,0.1);
        color: #fff;
      }
      #${n} .sos-followers-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px 16px;
        background: linear-gradient(90deg, #833ab4, #e1306c);
        border-radius: 12px 12px 0 0;
      }
      #${n} .sos-title { font-weight: 600; font-size: 14px; }
      #${n} .sos-header-actions { display: flex; gap: 8px; }
      #${n} .sos-header-actions button {
        background: rgba(255,255,255,0.2);
        border: none;
        color: white;
        width: 24px;
        height: 24px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s;
      }
      #${n} .sos-header-actions button:hover { background: rgba(255,255,255,0.3); }
      #${n} .sos-followers-body { padding: 16px; display: flex; flex-direction: column; gap: 12px; }
      #${n} .sos-field { display: flex; flex-direction: column; gap: 6px; }
      #${n} .sos-field.sos-inline { flex-direction: row; align-items: center; gap: 8px; }
      #${n} .sos-field.sos-inline label { flex-shrink: 0; }
      #${n} .sos-field.sos-inline input { width: 80px; text-align: center; }
      #${n} .sos-field.sos-inline span { color: #9ca3af; font-size: 12px; }
      #${n} label { font-size: 12px; color: #d1d5db; }
      #${n} input, #${n} select {
        background: #1f2937;
        border: 1px solid #374151;
        border-radius: 6px;
        padding: 10px 12px;
        font-size: 13px;
        color: #fff;
        transition: border-color 0.2s;
      }
      #${n} input:focus, #${n} select:focus {
        outline: none;
        border-color: #e1306c;
      }
      #${n} .sos-stats {
        display: flex;
        justify-content: space-around;
        background: rgba(0,0,0,0.3);
        padding: 12px;
        border-radius: 8px;
      }
      #${n} .stat-item { display: flex; flex-direction: column; align-items: center; }
      #${n} .stat-item .label { font-size: 10px; color: #9ca3af; text-transform: uppercase; }
      #${n} .stat-item .value { font-size: 20px; font-weight: bold; color: #fff; }
      #${n} .sos-btn-primary {
        width: 100%;
        padding: 12px;
        background: linear-gradient(135deg, #e1306c, #833ab4);
        border: none;
        border-radius: 6px;
        color: white;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.2s;
      }
      #${n} .sos-btn-primary:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(225, 48, 108, 0.4);
      }
      #${n} .sos-btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
      #${n} .sos-btn-stop { background: #ef4444 !important; }
      #${n} .sos-btn-secondary {
        width: 100%;
        padding: 12px;
        background: #4299e1;
        border: none;
        border-radius: 6px;
        color: white;
        font-weight: 600;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.2s;
      }
      #${n} .sos-btn-secondary:hover:not(:disabled) { background: #3182ce; }
      #${n} .sos-btn-secondary:disabled { opacity: 0.5; cursor: not-allowed; }
      #${n} .sos-warning {
        padding: 12px;
        background: rgba(59, 130, 246, 0.2);
        border: 1px solid rgba(59, 130, 246, 0.3);
        border-radius: 6px;
        font-size: 11px;
        color: #93c5fd;
        line-height: 1.4;
      }
      #${n} .sos-warning strong { color: #60a5fa; }
      #${n}.minimized .sos-followers-body { display: none; }
      #${n}.minimized { width: auto; }
      </style>
    `,document.body.appendChild(o),console.log("[Lia 360 UI] Followers overlay created"),I(),v()}function I(){document.getElementById("sos-start-scroll-btn")?.addEventListener("click",()=>{const t=window.LiaInstagramState;t&&(t.isAutoScrolling?window.LiaInstagramFollowers&&window.LiaInstagramFollowers.stopFollowersScanning():window.LiaInstagramFollowers&&window.LiaInstagramFollowers.startFollowersScanning())}),document.getElementById("sos-followers-import-btn")?.addEventListener("click",L),document.getElementById("sos-close-followers-btn")?.addEventListener("click",()=>{d()}),document.getElementById("sos-minimize-followers-btn")?.addEventListener("click",()=>{const t=document.getElementById(n);if(t){t.classList.toggle("minimized");const o=document.getElementById("sos-minimize-followers-btn");o&&(o.textContent=t.classList.contains("minimized")?"+":"\u2212")}}),document.getElementById("sos-followers-keywords")?.addEventListener("input",t=>{const o=window.LiaInstagramState;o&&(o.keywords=t.target.value.trim()?t.target.value.split(",").map(s=>s.trim()).filter(Boolean):[])}),document.getElementById("sos-scroll-limit")?.addEventListener("change",t=>{const o=window.LiaInstagramState;o&&(o.followersScrollLimit=parseInt(t.target.value)||300)});const e=t=>{t.key==="Escape"&&document.getElementById(n)&&(d(),document.removeEventListener("keydown",e))};document.addEventListener("keydown",e)}async function v(){const e=document.getElementById("sos-audience-select");if(e)try{const t=await new Promise(o=>{chrome.runtime.sendMessage({action:"getAudiences"},o)});if(t?.success&&t.data?.length>0){const o=window.LiaInstagramState;o&&(o.audiences=t.data),t.data.forEach(s=>{const r=document.createElement("option");r.value=s.id,r.textContent=s.name,e.appendChild(r)}),console.log(`[Lia 360 UI] Loaded ${t.data.length} audiences`)}}catch(t){console.error("[Lia 360 UI] Error loading audiences:",t)}}function m(){const e=window.LiaInstagramState;if(!e)return;const t=document.getElementById("sos-followers-scanned-count"),o=document.getElementById("sos-followers-qualified-count"),s=document.getElementById("sos-followers-import-btn");t&&(t.textContent=e.scannedCount),o&&(o.textContent=e.qualifiedLeads.size),s&&(s.textContent=`\u2601 Import ${e.qualifiedLeads.size} profiles...`,s.disabled=e.qualifiedLeads.size===0)}function h(e){const t=document.getElementById("sos-start-scroll-btn");t&&(e?(t.textContent="\u23F9 Stop Auto-Scroll",t.classList.add("sos-btn-stop")):(t.textContent="\u27F3 Start Auto-Scroll",t.classList.remove("sos-btn-stop")))}function d(){const e=document.getElementById(n);e&&(e.remove(),console.log("[Lia 360 UI] Followers overlay removed"));const t=window.LiaInstagramState;t&&t.isAutoScrolling&&window.LiaInstagramFollowers&&window.LiaInstagramFollowers.stopFollowersScanning()}async function L(){const e=window.LiaInstagramState;if(!e||e.qualifiedLeads.size===0){alert("No leads to import.");return}const t=Array.from(e.qualifiedLeads.values()),o=await chrome.runtime.sendMessage({action:"importLeads",data:{source:"extension",platform:"instagram",sourceUrl:window.location.href,leads:t}});o?.success?(alert(`Sucesso! ${t.length} leads importados.`),e.qualifiedLeads.clear(),e.scannedCount=0,e.totalUsersFound=0,m()):alert("Falha na importa\xE7\xE3o: "+(o?.error||"Erro desconhecido"))}function E(){if(document.getElementById("sos-post-actions-container"))return;const e=document.querySelector("article");if(!e)return;let t=e.querySelector('ul[class*="_a9z6"]');if(!t){const a=e.querySelectorAll("ul, div");for(const l of a){if(l.tagName==="HEADER"||l.querySelector("header"))continue;const u=window.getComputedStyle(l);if((u.overflowY==="auto"||u.overflowY==="scroll")&&l.clientHeight>50&&l.children.length>0){t=l;break}}}if(!t)return;const o=document.createElement("div");o.id="sos-post-actions-container",o.style.cssText=`
      position: sticky;
      top: 0;
      z-index: 1000;
      padding: 12px 16px;
      border-bottom: 1px solid rgb(38, 38, 38);
      display: flex;
      flex-direction: column;
      gap: 8px;
    `;try{let a=window.getComputedStyle(e).backgroundColor;(!a||a==="rgba(0, 0, 0, 0)"||a==="transparent")&&(a=window.getComputedStyle(t).backgroundColor),a&&a!=="rgba(0, 0, 0, 0)"&&a!=="transparent"?o.style.backgroundColor=a:o.style.backgroundColor="#000000"}catch{o.style.backgroundColor="#000000"}const s=document.createElement("button");s.id="sos-import-post-data-btn",s.innerHTML="\u2601\uFE0F Import This Post Data",s.style.cssText=`
      background-color: #3b82f6;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      height: 32px;
    `,s.addEventListener("click",async()=>{s.disabled=!0;const a=s.innerHTML;s.innerHTML="\u23F3 Importing...";try{if(window.LiaInstagramPost){const l=window.LiaInstagramPost.extractPostData();if(!l)throw new Error("Failed to extract post data");if((await chrome.runtime.sendMessage({action:"importPostData",data:l}))?.success)s.innerHTML="\u2705 Imported!",setTimeout(()=>{s.innerHTML=a,s.disabled=!1},2e3);else throw new Error("Import failed")}}catch(l){console.error("[Lia 360 UI] Import post error:",l),s.innerHTML="\u274C Error",setTimeout(()=>{s.innerHTML=a,s.disabled=!1},2e3)}});const r=document.createElement("button");r.id="sos-auto-reply-btn",r.innerHTML="\u21A9\uFE0F Auto-Reply to Comments",r.style.cssText=`
      background-color: #10b981;
      color: white;
      border: none;
      border-radius: 4px;
      padding: 8px;
      font-weight: 600;
      font-size: 14px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      width: 100%;
      height: 32px;
    `,o.appendChild(s),o.appendChild(r),t.firstChild?t.insertBefore(o,t.firstChild):t.appendChild(o),console.log("[Lia 360 UI] Post buttons injected")}function $(){const e=document.getElementById("sos-post-actions-container");e&&e.remove()}window.LiaInstagramUI={createOverlay:f,createFollowersOverlay:x,removeFollowersOverlay:d,updateFollowersStats:m,updateScrollButtonState:h,injectPostButtons:E,removePostButtons:$},console.log("[Lia 360 UI] UI module loaded")})();
//# sourceMappingURL=ui.js.map
