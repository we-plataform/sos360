"use strict";(function(){"use strict";console.log("[Lia 360 Sync] Dashboard sync script loaded on:",window.location.href);async function i(){try{const e=localStorage.getItem("accessToken"),n=localStorage.getItem("refreshToken");if(e){console.log("[Lia 360 Sync] Found tokens in localStorage, syncing to extension...");const t=await chrome.runtime.sendMessage({action:"syncAuth",data:{accessToken:e,refreshToken:n}});t?.success?(console.log("[Lia 360 Sync] Auth synced successfully!"),s("Extension sincronizada!","success")):console.warn("[Lia 360 Sync] Auth sync failed:",t?.error)}else console.log("[Lia 360 Sync] No tokens found in localStorage")}catch(e){console.error("[Lia 360 Sync] Error syncing auth:",e)}}window.addEventListener("message",async e=>{if(e.origin!==window.location.origin)return;const{type:n,jobId:t}=e.data||{};if(n==="SOS360_TRIGGER_AUTOMATION"){console.log("[Lia 360 Sync] Received automation trigger for job:",t);try{(await chrome.runtime.sendMessage({action:"triggerImmediatePoll"}))?.success&&(console.log("[Lia 360 Sync] Immediate poll triggered"),s("Automa\xE7\xE3o detectada! Abrindo LinkedIn...","info"))}catch(o){console.error("[Lia 360 Sync] Error triggering poll:",o),o.message.includes("Extension context invalidated")?s("Extens\xE3o atualizada. Por favor, recarregue a p\xE1gina.","error"):s("Erro ao comunicar com a extens\xE3o.","error")}}});function s(e,n="info"){const t=document.getElementById("sos360-sync-notification");t&&t.remove();const o=document.createElement("div");o.id="sos360-sync-notification",o.innerHTML=`
      <div style="
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: ${n==="success"?"#10b981":n==="error"?"#ef4444":"#3b82f6"};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        font-family: -apple-system, system-ui, sans-serif;
        font-size: 14px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        z-index: 999999;
        display: flex;
        align-items: center;
        gap: 8px;
        animation: slideIn 0.3s ease;
      ">
        <span style="font-size: 18px;">${n==="success"?"\u2713":n==="error"?"\u2717":"\u2139"}</span>
        <span>${e}</span>
      </div>
      <style>
        @keyframes slideIn {
          from { transform: translateX(-100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      </style>
    `,document.body.appendChild(o),setTimeout(()=>{o.style.transition="opacity 0.3s ease, transform 0.3s ease",o.style.opacity="0",o.style.transform="translateX(-100%)",setTimeout(()=>o.remove(),300)},4e3)}async function r(){try{const e=await chrome.runtime.sendMessage({action:"getExtensionStatus"});e?.success&&(console.log("[Lia 360 Sync] Extension status:",e),e.isAuthenticated||c())}catch(e){console.log("[Lia 360 Sync] Could not check extension status:",e)}}function c(){if(document.getElementById("sos360-auth-warning"))return;const e=document.createElement("div");e.id="sos360-auth-warning",e.innerHTML=`
      <div style="
        position: fixed;
        top: 80px;
        right: 20px;
        background: #fef3c7;
        border: 1px solid #f59e0b;
        color: #92400e;
        padding: 16px 20px;
        border-radius: 8px;
        font-family: -apple-system, system-ui, sans-serif;
        font-size: 13px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        z-index: 999998;
        max-width: 320px;
      ">
        <div style="display: flex; align-items: flex-start; gap: 10px;">
          <span style="font-size: 20px;">\u26A0\uFE0F</span>
          <div>
            <div style="font-weight: 600; margin-bottom: 4px;">Extens\xE3o n\xE3o autenticada</div>
            <div style="font-size: 12px; opacity: 0.9;">
              A extens\xE3o Lia 360 precisa estar logada para executar automa\xE7\xF5es. 
              Clique no \xEDcone da extens\xE3o e fa\xE7a login.
            </div>
            <button id="sos360-sync-now-btn" style="
              margin-top: 8px;
              background: #f59e0b;
              color: white;
              border: none;
              padding: 6px 12px;
              border-radius: 4px;
              font-size: 12px;
              cursor: pointer;
            ">Sincronizar Agora</button>
          </div>
          <button id="sos360-close-warning" style="
            background: none;
            border: none;
            color: #92400e;
            font-size: 18px;
            cursor: pointer;
            padding: 0;
            line-height: 1;
            opacity: 0.7;
          ">\xD7</button>
        </div>
      </div>
    `,document.body.appendChild(e),document.getElementById("sos360-close-warning").addEventListener("click",()=>{e.remove()}),document.getElementById("sos360-sync-now-btn").addEventListener("click",async()=>{await i(),e.remove()})}document.readyState==="complete"?a():window.addEventListener("load",a);async function a(){console.log("[Lia 360 Sync] Initializing..."),await new Promise(n=>setTimeout(n,500)),await i(),await r();const e=localStorage.setItem;localStorage.setItem=function(n,t){e.apply(this,arguments),(n==="accessToken"||n==="refreshToken")&&(console.log("[Lia 360 Sync] Token changed, re-syncing..."),setTimeout(i,100))},console.log("[Lia 360 Sync] Initialization complete")}})();
//# sourceMappingURL=dashboard-sync.js.map
