"use strict";(function(){"use strict";console.log("[Lia 360] Loading UI module...");const i="sos360-linkedin-overlay",p="sos360-automation-overlay",r=window.LiaUtils,d=window.LiaState;if(!r||!d){console.error("[Lia 360] Missing dependencies (Utils/State). Check load order.");return}console.log("[Lia 360] UI dependencies OK"),window.LiaUI={UI_ID:i,getMenuStyles:()=>`
        .lia-profile-menu { position: fixed; bottom: 20px; right: 20px; z-index: 10000; font-family: -apple-system, system-ui, sans-serif; }
        .lia-profile-menu-card { background: #1f2937; color: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.3); width: 300px; overflow: hidden; animation: slideIn 0.3s ease; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        .lia-profile-menu-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #111827; border-radius: 8px 8px 0 0; border-bottom: 1px solid #374151; }
        .lia-profile-menu-title { font-weight: 600; font-size: 14px; color: #fff; }
        .lia-profile-menu-close { background: none; border: none; color: #9ca3af; font-size: 20px; cursor: pointer; padding: 0; line-height: 1; transition: color 0.2s; }
        .lia-profile-menu-close:hover { color: #fff; }
        .lia-profile-menu-body { padding: 16px; }
        .lia-profile-import-btn { width: 100%; padding: 10px; background: #3b82f6; color: white; border: none; border-radius: 4px; font-weight: 600; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px; transition: opacity 0.2s; }
        .lia-profile-import-btn:hover:not(:disabled) { opacity: 0.9; }
        .lia-profile-import-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .lia-profile-status { margin-top: 12px; font-size: 13px; text-align: center; min-height: 20px; }
        .lia-profile-status.success { color: #10b981; }
        .lia-profile-status.error { color: #ef4444; }
        .lia-profile-status.loading { color: #9ca3af; }
    `,PipelineDialog:class{constructor(){this.dialogId="sos-pipeline-dialog",this.state={pipelines:[],selectedPipeline:null,selectedStage:null,leadsToImport:[]},this.isRendered=!1}render(){if(document.getElementById(this.dialogId))return;const e=document.createElement("div");e.id=this.dialogId,e.className="sos-dialog",e.style.display="none",e.innerHTML=`
                <div class="sos-dialog-overlay"></div>
                <div class="sos-dialog-content">
                  <div class="sos-dialog-header">
                    <span>\u{1F4C1} Selecionar Destino</span>
                    <button class="sos-close-btn" id="sos-dialog-close">&times;</button>
                  </div>
                  <div class="sos-dialog-body">
                    <div class="sos-form-group">
                      <label>Pipeline</label>
                      <select id="sos-pipeline-select">
                        <option value="">Carregando...</option>
                      </select>
                    </div>
                    <div class="sos-form-group">
                      <label>Coluna/Est\xE1gio</label>
                      <select id="sos-stage-select" disabled>
                        <option value="">Selecione um pipeline primeiro</option>
                      </select>
                    </div>
                    <div id="sos-import-summary" style="margin-top: 12px; padding: 12px; background: #111827; border-radius: 6px; text-align: center;">
                       <!-- Summary injected here -->
                    </div>
                  </div>
                  <div class="sos-dialog-footer">
                    <button id="sos-cancel-import" class="sos-btn" style="background: #374151;">Cancelar</button>
                    <button id="sos-confirm-import" class="sos-btn sos-btn-action" disabled>
                      Confirmar Importa\xE7\xE3o
                    </button>
                  </div>
                </div>
                ${this.getStyles()}
                `,document.body.appendChild(e),this.bindEvents(),this.isRendered=!0}getStyles(){return`
                <style>
                  #${this.dialogId} { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 2147483648; display: flex; align-items: center; justify-content: center; font-family: -apple-system, system-ui, sans-serif; }
                  #${this.dialogId} .sos-dialog-overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.6); }
                  #${this.dialogId} .sos-dialog-content { position: relative; background: #1f2937; border-radius: 12px; width: 340px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); animation: sos-dialog-in 0.2s ease; color: white; }
                  @keyframes sos-dialog-in { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
                  #${this.dialogId} .sos-dialog-header { display: flex; justify-content: space-between; align-items: center; padding: 16px; border-bottom: 1px solid #374151; font-weight: 600; }
                  #${this.dialogId} .sos-close-btn { background: none; border: none; color: #9ca3af; font-size: 20px; cursor: pointer; padding: 0; line-height: 1; }
                  #${this.dialogId} .sos-close-btn:hover { color: #fff; }
                  #${this.dialogId} .sos-dialog-body { padding: 16px; }
                  #${this.dialogId} .sos-form-group { margin-bottom: 16px; }
                  #${this.dialogId} .sos-form-group label { display: block; margin-bottom: 8px; font-size: 12px; color: #9ca3af; }
                  #${this.dialogId} .sos-form-group select { 
                    width: 100%; 
                    height: 44px;
                    padding: 0 12px;
                    line-height: 44px;
                    box-sizing: border-box;
                    background-color: #374151 !important; 
                    border: 1px solid #4b5563 !important; 
                    border-radius: 6px !important; 
                    color: #fff !important; 
                    font-size: 14px !important; 
                    cursor: pointer; 
                    appearance: none; 
                    -webkit-appearance: none;
                    background-image: url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23FFFFFF%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E");
                    background-repeat: no-repeat;
                    background-position: right 12px center;
                    background-size: 10px auto;
                  }
                  #${this.dialogId} .sos-form-group select:disabled { opacity: 0.5; cursor: not-allowed; }
                  #${this.dialogId} .sos-form-group select:focus { outline: none; border-color: #3b82f6; }
                  #${this.dialogId} .sos-dialog-footer { display: flex; gap: 8px; padding: 16px; border-top: 1px solid #374151; }
                  #${this.dialogId} .sos-btn { flex: 1; padding: 10px; border: none; border-radius: 4px; font-weight: 600; font-size: 14px; cursor: pointer; color: white; transition: opacity 0.2s; }
                  #${this.dialogId} .sos-btn:hover:not(:disabled) { opacity: 0.9; }
                  #${this.dialogId} .sos-btn:disabled { opacity: 0.5; cursor: not-allowed; }
                  #${this.dialogId} .sos-btn-action { background: #3b82f6; }
                </style>
                `}bindEvents(){const e=document.getElementById(this.dialogId);e.querySelector("#sos-dialog-close").onclick=()=>this.close(),e.querySelector("#sos-cancel-import").onclick=()=>this.close(),e.querySelector(".sos-dialog-overlay").onclick=()=>this.close(),e.querySelector("#sos-pipeline-select").onchange=t=>{this.state.selectedPipeline=t.target.value,this.updateStages(t.target.value)},e.querySelector("#sos-stage-select").onchange=t=>{this.state.selectedStage=t.target.value;const o=e.querySelector("#sos-confirm-import");o.disabled=!t.target.value},e.querySelector("#sos-confirm-import").onclick=()=>this.confirmImport()}open(e){this.render(),this.state.leadsToImport=Array.isArray(e)?e:[e];const t=document.getElementById(this.dialogId),o=document.getElementById("sos-import-summary");o.innerHTML=`
                    <div style="font-size: 24px; font-weight: bold; color: #10b981;">${this.state.leadsToImport.length}</div>
                    <div style="font-size: 11px; color: #9ca3af;">leads ser\xE3o importados</div>
                `,t.style.display="flex",this.loadPipelines()}close(){const e=document.getElementById(this.dialogId);e&&(e.style.display="none"),this.state.selectedPipeline=null,this.state.selectedStage=null}async loadPipelines(){const e=document.getElementById("sos-pipeline-select"),t=document.getElementById("sos-stage-select"),o=document.getElementById("sos-confirm-import");e.innerHTML='<option value="">Carregando...</option>',t.disabled=!0,o.disabled=!0;try{const s=await chrome.runtime.sendMessage({action:"getPipelines"});if(s.success&&s.data){this.state.pipelines=s.data,e.innerHTML='<option value="">Selecione um pipeline</option>',this.state.pipelines.forEach(a=>{const l=document.createElement("option");l.value=a.id,l.textContent=a.name+(a.isDefault?" \u2B50":""),e.appendChild(l)});const n=this.state.pipelines.find(a=>a.isDefault);n&&(e.value=n.id,this.state.selectedPipeline=n.id,this.updateStages(n.id))}else e.innerHTML='<option value="">Erro ao carregar</option>'}catch(s){console.error("[Lia 360] Erro loading pipelines:",s),e.innerHTML='<option value="">Erro de conex\xE3o</option>'}}updateStages(e){const t=document.getElementById("sos-stage-select"),o=document.getElementById("sos-confirm-import");if(!e){t.innerHTML='<option value="">Selecione um pipeline primeiro</option>',t.disabled=!0,o.disabled=!0;return}const s=this.state.pipelines.find(n=>n.id===e);if(!s||!s.stages||s.stages.length===0){t.innerHTML='<option value="">Nenhuma coluna encontrada</option>',t.disabled=!0,o.disabled=!0;return}t.innerHTML="",s.stages.forEach(n=>{const a=document.createElement("option");a.value=n.id,a.textContent=n.name,t.appendChild(a)}),t.disabled=!1,s.stages.length>0&&(t.value=s.stages[0].id,this.state.selectedStage=s.stages[0].id,o.disabled=!1)}async confirmImport(){const e=document.getElementById("sos-confirm-import"),t=this.state.selectedStage;if(t){e.disabled=!0,e.textContent="Importando...";try{const o=await chrome.runtime.sendMessage({action:"importLeads",data:{source:"extension",platform:"linkedin",sourceUrl:window.location.href,leads:this.state.leadsToImport,pipelineStageId:t}});o&&o.success?(this.close(),window.dispatchEvent(new CustomEvent("lia-import-success",{detail:{count:this.state.leadsToImport.length}}))):alert("Erro na importa\xE7\xE3o: "+(o?.error||"Unknown error"))}catch(o){alert("Erro: "+o.message)}finally{e.disabled=!1,e.textContent="Confirmar Importa\xE7\xE3o"}}}},ProfileImportMenu:class{constructor(){this.host=null,this.shadow=null,this.container=null,this.createMenu(),this.attachEvents(),window.LiaUI.pipelineDialog||(window.LiaUI.pipelineDialog=new window.LiaUI.PipelineDialog),window.addEventListener("lia-import-success",()=>this.onImportSuccess())}createMenu(){const e=document.getElementById("lia-profile-menu-host");if(e&&e.shadowRoot){this.host=e,this.shadow=this.host.shadowRoot,this.container=this.shadow.querySelector(".lia-profile-menu");return}e&&e.remove(),this.host=document.createElement("div"),this.host.id="lia-profile-menu-host",document.body.appendChild(this.host),this.shadow=this.host.attachShadow({mode:"open"});const t=document.createElement("style");t.textContent=window.LiaUI.getMenuStyles(),this.shadow.appendChild(t),this.container=document.createElement("div"),this.container.className="lia-profile-menu",this.container.innerHTML=`
          <div class="lia-profile-menu-card">
            <div class="lia-profile-menu-header">
              <span class="lia-profile-menu-title">Importar Perfil</span>
              <button class="lia-profile-menu-close" aria-label="Fechar">\xD7</button>
            </div>
            <div class="lia-profile-menu-body">
              <button class="lia-profile-import-btn">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                  <polyline points="17 8 12 3 7 8"></polyline>
                  <line x1="12" y1="3" x2="12" y2="15"></line>
                </svg>
                Importar Perfil
              </button>
            <div class="lia-profile-status"></div>
              <div style="margin-top: 8px; font-size: 11px; color: #6b7280; text-align: center; border-top: 1px solid #374151; padding-top: 8px;">
                     Debug Stats: <span id="lia-debug-followers">Loading...</span>
              </div>
            </div>
          </div>
        `,this.shadow.appendChild(this.container),setTimeout(()=>{if(window.LiaDOM&&window.LiaDOM.getQuickStats){const o=window.LiaDOM.getQuickStats(),s=this.shadow.querySelector("#lia-debug-followers");s&&(s.textContent=`${o.followers} seguidores`)}},500)}attachEvents(){this.shadow&&(this.shadow.querySelector(".lia-profile-menu-close").addEventListener("click",()=>this.hide()),this.shadow.querySelector(".lia-profile-import-btn").addEventListener("click",()=>this.startImport()))}async startImport(){const e=this.shadow.querySelector(".lia-profile-import-btn"),t=this.shadow.querySelector(".lia-profile-status");if(!(!e||!t)){e.disabled=!0,e.innerHTML="Carregando...",t.className="lia-profile-status loading",t.textContent="Extraindo dados...";try{const o=await window.LiaDOM.extractCurrentProfile();if(!o)throw new Error("N\xE3o foi poss\xEDvel extrair dados do perfil");if(t.textContent="",t.className="lia-profile-status",e.disabled=!1,e.innerHTML=`
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                        <polyline points="17 8 12 3 7 8"></polyline>
                        <line x1="12" y1="3" x2="12" y2="15"></line>
                        </svg>
                        Importar Perfil
                    `,window.LiaUI.pipelineDialog)window.LiaUI.pipelineDialog.open(o);else throw new Error("Pipeline dialog not initialized")}catch(o){console.error("[Lia 360] Erro ao preparar importa\xE7\xE3o:",o),t.className="lia-profile-status error",t.textContent="\u2717 "+o.message,e.disabled=!1,e.innerHTML="Importar Perfil"}}}onImportSuccess(){const e=this.shadow.querySelector(".lia-profile-import-btn"),t=this.shadow.querySelector(".lia-profile-status");t.className="lia-profile-status success",t.textContent="\u2713 Perfil importado com sucesso!",e.innerHTML="\u2713 Importado",e.disabled=!1}show(){this.container&&(this.container.style.display="block")}hide(){this.container&&(this.container.style.display="none")}remove(){this.host&&this.host.remove()}},createOverlay:function(){if(console.log("[Lia 360] createOverlay() called"),document.getElementById(i)){console.log("[Lia 360] Overlay already exists, showing it"),document.getElementById(i).style.display="block";return}console.log("[Lia 360] Creating new overlay element");const e=document.createElement("div");e.id=i,e.innerHTML=`
                <div class="sos-header">
                    <span class="sos-title">\u26A1 Connections Mining</span>
                    <button id="sos-close" class="sos-close">&times;</button>
                </div>
                <div class="sos-content">
                    <!-- Audience Selector -->
                    <div class="sos-form-group">
                        <label for="sos-audience-select">Filter by Audience</label>
                        <select id="sos-audience-select">
                            <option value="">All Connections (No Filter)</option>
                        </select>
                    </div>

                    <!-- Stats Panel -->
                    <div class="sos-stats-panel">
                        <div class="sos-stat">
                            <div class="sos-stat-value" id="sos-scanned-count">0</div>
                            <div class="sos-stat-label">Scanned</div>
                        </div>
                        <div class="sos-stat">
                            <div class="sos-stat-value" id="sos-qualified-count">0</div>
                            <div class="sos-stat-label">Qualified</div>
                        </div>
                        <div class="sos-stat">
                            <div class="sos-stat-value" id="sos-filter-rate">0%</div>
                            <div class="sos-stat-label">Match Rate</div>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="sos-actions">
                        <button id="sos-start-btn" class="sos-btn sos-btn-primary">\u25B6 Start Mining</button>
                        <button id="sos-stop-btn" class="sos-btn sos-btn-danger" style="display: none;">\u23F8 Stop</button>
                        <button id="sos-import-btn" class="sos-btn sos-btn-success" disabled>\u{1F4E5} Import (0)</button>
                    </div>
                </div>
                ${this.getOverlayStyles()}
            `,document.body.appendChild(e),console.log("[Lia 360] Overlay added to DOM successfully")},getOverlayStyles:()=>`
            <style>
                #${i} { position: fixed; bottom: 20px; right: 20px; width: 320px; background: #1f2937; color: white; border-radius: 8px; z-index: 10000; font-family: -apple-system, system-ui, sans-serif; }
                #${i} .sos-header { display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; background: #111827; border-radius: 8px 8px 0 0; border-bottom: 1px solid #374151; }
                #${i} .sos-title { font-weight: 600; font-size: 14px; }
                #${i} .sos-close { background: none; border: none; color: #9ca3af; font-size: 20px; cursor: pointer; padding: 0; line-height: 1; }
                #${i} .sos-close:hover { color: #fff; }
                #${i} .sos-content { padding: 16px; }

                #${i} .sos-form-group { margin-bottom: 12px; }
                #${i} .sos-form-group label { display: block; font-size: 12px; color: #9ca3af; margin-bottom: 4px; }
                #${i} .sos-form-group select {
                    width: 100%;
                    padding: 8px;
                    background: #374151;
                    border: 1px solid #4b5563;
                    border-radius: 4px;
                    color: white;
                    font-size: 14px;
                }

                #${i} .sos-stats-panel {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 8px;
                    margin: 12px 0;
                    padding: 12px;
                    background: #111827;
                    border-radius: 6px;
                }
                #${i} .sos-stat { text-align: center; }
                #${i} .sos-stat-value { font-size: 20px; font-weight: bold; color: #10b981; }
                #${i} .sos-stat-label { font-size: 10px; color: #9ca3af; text-transform: uppercase; margin-top: 2px; }

                #${i} .sos-actions { display: flex; flex-direction: column; gap: 8px; }
                #${i} .sos-btn {
                    width: 100%;
                    padding: 10px;
                    border: none;
                    border-radius: 4px;
                    font-weight: 600;
                    font-size: 14px;
                    cursor: pointer;
                    color: white;
                    transition: opacity 0.2s;
                }
                #${i} .sos-btn:hover:not(:disabled) { opacity: 0.9; }
                #${i} .sos-btn:disabled { opacity: 0.5; cursor: not-allowed; }
                #${i} .sos-btn-primary { background: #3b82f6; }
                #${i} .sos-btn-danger { background: #ef4444; }
                #${i} .sos-btn-success { background: #10b981; }
            </style>
        `,updateUI:function(){const e=window.LiaState.get(),t=document.getElementById("sos-scanned-count"),o=document.getElementById("sos-qualified-count"),s=document.getElementById("sos-filter-rate");if(t&&(t.textContent=e.totalConnectionsFound),o&&(o.textContent=e.qualifiedLeads.size),s){const c=e.totalConnectionsFound>0?Math.round(e.qualifiedLeads.size/e.totalConnectionsFound*100):0;s.textContent=c+"%"}const n=document.getElementById("sos-import-btn");n&&(n.disabled=e.qualifiedLeads.size===0,n.textContent=`\u{1F4E5} Import (${e.qualifiedLeads.size})`);const a=document.getElementById("sos-start-btn"),l=document.getElementById("sos-stop-btn");a&&l&&(e.isAutoScrolling?(a.style.display="none",l.style.display="inline-block"):(a.style.display="inline-block",l.style.display="none"))},loadAudiences:async function(){try{const e=await chrome.runtime.sendMessage({action:"getAudiences"});if(e?.success&&e.data?.length>0){const t=document.getElementById("sos-audience-select");if(!t)return;t.innerHTML='<option value="">All Connections (No Filter)</option>',e.data.forEach(o=>{const s=document.createElement("option");s.value=o.id,s.textContent=o.name,t.appendChild(s)})}}catch(e){console.error("[Lia 360] Error loading audiences:",e)}},updateScrollStatus:function(e,t=null){const o=document.getElementById(i);if(!o)return;let s=document.getElementById("sos-scroll-status");s||(s=document.createElement("div"),s.id="sos-scroll-status",s.style.cssText="margin-top: 8px; font-size: 11px; color: #9ca3af; text-align: center;",o.querySelector(".sos-content").appendChild(s)),s.textContent=e,t!==null&&(s.textContent=`${e} (${t}%)`)}},console.log("[Lia 360] UI Module Loaded")})();
//# sourceMappingURL=linkedin-ui.js.map
